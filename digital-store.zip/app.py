from flask import Flask, render_template, request, redirect, url_for, jsonify, session

app = Flask(__name__)
app.secret_key = 'supersecretkey'

products = [
    {'id': 1, 'name': 'Электронная книга', 'price': 499, 'description': 'Удобная электронная книга.', 'image': '/static/images/book.png'},
    {'id': 2, 'name': 'Музыкальный альбом', 'price': 149, 'description': 'Музыкальный альбом.', 'image': '/static/images/music.png'},
    {'id': 3, 'name': 'Программное обеспечение', 'price': 999, 'description': 'Программа.', 'image': '/static/images/software.png'}
]

@app.route('/')
def index():
    return render_template('index.html', products=products)

@app.route('/cart')
def cart():
    cart_items = session.get('cart', [])
    total_price = sum(item['price'] for item in cart_items)
    return render_template('cart.html', cart=cart_items, total_price=total_price)

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    product_id = int(request.form.get('product_id'))
    product = next((p for p in products if p['id'] == product_id), None)
    if product:
        cart = session.get('cart', [])
        cart.append(product)
        session['cart'] = cart
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    app.run(debug=True)
